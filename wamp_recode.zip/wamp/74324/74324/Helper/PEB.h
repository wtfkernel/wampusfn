#pragma once

extern "C" PEB* GetPEB();